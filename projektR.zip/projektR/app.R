library(shiny)
library(psych)
library(ggplot2)
library(dplyr)
library(shinythemes)

dane <- ToothGrowth
colnames(dane) <- c("dlugosc", "suplement", "dawkowanie")
dane$suplement <- as.factor(dane$suplement)

# UI
ui <- fluidPage(
  titlePanel("Analiza danych - ToothGrowth"),
  navbarPage(title = "",
             tabPanel("Statystyki ",
                      sidebarLayout(
                        sidebarPanel(
                          selectInput(inputId = "stat", 
                                      label = "Statystyki",
                                      choices = c("Długość zębów",
                                                  "Dlugość zębów ze względu na dawkowanie",
                                                  "Długość zębów ze względu na suplementacje"), 
                                      selected = "Długość zębów")
                        ),
                        mainPanel(
                          tableOutput("stat1"),
                          plotOutput("plot1")
                          
                        )
                      )
             ),
             tabPanel("Wykresy gęstości",
                      sidebarLayout(
                        sidebarPanel(
                          selectInput(inputId = "dens",
                                      label = "Wykresy gętości - różne czynniki",
                                      choices = c("Długość zębów w zależności od dawkowania", 
                                                  "Długość zębów w zależności od suplementacji"),
                                      selected = "Długość zębów w zależności od dawkowania")
                        ),
                        mainPanel(
                          plotOutput("plot2")
                        )
                      )
                    )
)
)

# Server
server <- function(input, output) {
  output$stat1 <- renderTable({
    if(input$stat == "Długość zębów"){
      dane %>%
        summarise(
          srednia = mean(dlugosc),
          odchylenie_stan = sd(dlugosc),
          wariancja = var(dlugosc),
          mediana = median(dlugosc),
          zakres_min = min(dlugosc),
          zakres_max = max(dlugosc),
          skosnosc = skew(dlugosc),
          kurtoza = kurtosi(dlugosc)
        )
    }else if (input$stat == "Długość zębów ze względu na dawkowanie"){
      dane %>%
        group_by(dawkowanie) %>%
        summarise(
          srednia = mean(dlugosc),
          odchylenie_stan = sd(dlugosc),
          wariancja = var(dlugosc),
          mediana = median(dlugosc),
          zakres_min = min(dlugosc),
          zakres_max = max(dlugosc),
          skosnosc = skew(dlugosc),
          kurtoza = kurtosi(dlugosc))
    }else{
      dane %>%
        group_by(suplement) %>%
        summarise(
          srednia = mean(dlugosc),
          odchylenie_standardowe = sd(dlugosc),
          wariancja = var(dlugosc),
          mediana = median(dlugosc),
          zakres_min = min(dlugosc),
          zakres_max = max(dlugosc),
          skosnosc = skew(dlugosc),
          kurtoza = kurtosi(dlugosc))
    }
  })
  output$plot1 <- renderPlot({
    if (input$stat == "Długość zębów"){
      dane %>%
        ggplot()+
        geom_histogram(aes(x=dlugosc), binwidth = 1, fill = "skyblue", color = "black", alpha = 0.7)+
        labs(title = "Histogram dla długości zębów świnek")
    }
    else if (input$stat == "Długość zębów ze względu na dawkowanie"){
      dane %>%
        ggplot()+
        geom_boxplot(aes(x = factor(dawkowanie), y = dlugosc),fill = "green", color = "darkgreen", width = 0.5)+
        labs(title = "Dawkowanie a długość zębów - Wykres Pudełkowy", x = "Dawkowanie", y = "Długość")+
        theme_minimal()
    }
    else {
      dane %>%
        ggplot()+
        geom_boxplot(aes(x = factor(suplement), y = dlugosc), fill = "lightblue", color = "darkblue", width = 0.5)+
        labs(title = "Suplement a długość zębów - Wykres Pudełkowy", x = "Suplement", y = "Długość")+
        scale_x_discrete(labels = c("Sok pomarańczowy", "Kwas askorbinowy"))+
        theme_minimal()
    }
  })
  output$plot2 <- renderPlot({
    if(input$dens == "Długość zębów w zależności od dawkowania"){
      dane %>%
        ggplot(aes(x = dlugosc, fill = factor(dawkowanie)))+
        geom_density(alpha = 0.5)+
        scale_fill_discrete(name = "Dawkowanie")+
        labs(x = "Długość", y = "Gęstość")
    }
    else{
      dane%>%
        ggplot(aes(x = dlugosc, fill = factor(suplement)))+
        geom_density(alpha = 0.5)+
        scale_fill_discrete(name = "Suplement", labels = c("Sok pomarańczowy", "Kwas askorbinowy"))+
        labs(x = "Długość", y = "Gęstość")
    }
  })
}


# Uruchom aplikację Shiny
shinyApp(ui = ui, server = server)

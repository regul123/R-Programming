library(dplyr)
library(ggplot2)
library(moments)

dane <- ToothGrowth

colnames(dane) <- c("dlugosc", "suplement", "dawkowanie" )

#statystyki dla dlugosci
statystyki1 <- dane %>%
  summarise(
    srednia = mean(dlugosc),
    odchylenie_stan = sd(dlugosc),
    wariancja = var(dlugosc),
    mediana = median(dlugosc),
    zakres_min = min(dlugosc),
    zakres_max = max(dlugosc),
    skosnosc = skewness(dlugosc),
    kurtoza = kurtosis(dlugosc)
  )
print(statystyki1)


#podstawowe statyski opisowe pogrupowane wzgledem dawkowanie
statystyki3 <- dane %>%
  group_by(dawkowanie) %>%
  summarise(
    srednia = mean(dlugosc),
    odchylenie_stan = sd(dlugosc),
    wariancja = var(dlugosc),
    mediana = median(dlugosc),
    zakres_min = min(dlugosc),
    zakres_max = max(dlugosc),
    skosnosc = skewness(dlugosc),
    kurtoza = kurtosis(dlugosc)
  )
print(statystyki3)

#podstawowe statyski opisowe pogrupowane wzgledem suplement
statystyki4 <- dane %>%
  group_by(suplement) %>%
  summarise(
    srednia = mean(dlugosc),
    odchylenie_stan = sd(dlugosc),
    wariancja = var(dlugosc),
    mediana = median(dlugosc),
    zakres_min = min(dlugosc),
    zakres_max = max(dlugosc),
    skosnosc = skewness(dlugosc),
    kurtoza = kurtosis(dlugosc)
  )
print(statystyki4)

#podstawowe wykresy statysyczne 

dane %>%
  ggplot()+
  geom_boxplot(aes(y=dlugosc), binwidth = 1, fill = "skyblue", color = "black", alpha = 0.7)+
  labs(title = "Wykres pudełkowy dla długości zębów świnek")


boxplot_dawkowanie <- ggplot(dane, aes(x = factor(dawkowanie), y = dlugosc))+
  geom_boxplot(fill = "green", color = "darkgreen", width = 0.5)+
  labs(title = "Dawkowanie a długość zębów - Wykres Pudełkowy", x = "Dawkowanie", y = "Długość")+
  theme_minimal()
boxplot_dawkowanie  

density_dawkowanie <- ggplot(dane, aes(x = dlugosc, fill = factor(dawkowanie)))+
  geom_density(alpha = 0.5)+
  scale_fill_discrete(name = "Dawkowanie")+
  labs(title = "Długość zęba a dawkowanie - Wykres Gęstości", x = "Długość", y = "Gęstość")
  
density_dawkowanie

boxplot_suplement <- ggplot(dane, aes(x = factor(suplement), y = dlugosc))+
  geom_boxplot(fill = "lightblue", color = "darkblue", width = 0.5)+
  labs(title = "Suplement a długość zębów - Wykres Pudełkowy", x = "Suplement", y = "Długość")+
  scale_x_discrete(labels = c("Sok pomarańczowy", "Kwas askorbinowy"))+
  theme_minimal()
boxplot_suplement  

density_suplement <- ggplot(dane, aes(x = dlugosc, fill = factor(suplement)))+
  geom_density(alpha = 0.5)+
  scale_fill_discrete(name = "Suplement", labels = c("Sok pomarańczowy", "Kwas askorbinowy"))+
  labs(title = "Długość zęba a podawany suplement - Wykres Gęstości", x = "Długość", y = "Gęstość")

density_suplement

#wykres kolowy pokazujacy ile świnek bylo karmionych sokiem a ile kwasem 


#ANALIZA WARIANCJI 


# Weryfikacja założeń analizy wariancji
bartlett_dose <- bartlett.test(dane$dlugosc ~ dane$dawkowanie)
print(bartlett_dose)

bartlett_supp <- bartlett.test(dane$dlugosc ~ dane$suplement)
print(bartlett_supp)

#test normalności

tapply(dane$dlugosc, dane$suplement, shapiro.test)

tapply(dane$dlugosc, dane$dawkowanie, shapiro.test)




#przechodze do weryfikacji zalozen 

tapply(dane$dlugosc, dane$suplement, shapiro.test)

#ladnie wychodza dane wiec wartosci oczekiwane nie roznia sie istotnie dla dawkowania 
dane$dawkowanie <- as.factor(dane$dawkowanie)
#two ways anova 

# Sprawdzenie równości średnich cen w różnych grupach
anova_dose <- aov(dlugosc ~ dawkowanie, data = dane)
anova_supp <- aov(dlugosc ~ suplement, data = dane)

print(summary(anova_dose))

#p value za małe, wariancja błędna 

print(summary(anova_supp))


tukey.oneway <- TukeyHSD(anova_dose)
tukey.oneway

dane %>%
  ggplot()+
  geom_boxplot(aes(x = factor(dawkowanie), y = dlugosc),fill = "green", color = "darkgreen", width = 0.5)+
  labs(title = "Dawkowanie a długość zębów - Wykres Pudełkowy", x = "Dawkowanie", y = "Długość")+
  theme_minimal()
